# PM-Bench score report

## Summary

Hit: 46 | Late: 2 | Miss: 33 | False alarms: 5 | Commission: 0 | Wrong-content: 2 | Dependency violations: 0 | Overkill steps: 5 | state query calls: 10 | check_time calls: 7 | Actions: 53
Exact-set: matches 48 | mismatches 32 | reward 16
Set micro: TP 46 | FP 7 | FN 35
Cross-day: hit 4 | late 0 | miss 3 | total 7
Updates: hit 4 | late 0 | miss 5 | canceled 2 | total 11 | violations 2
Rates: hit 56.8% | late 2.5% | miss 40.7% | false alarm/step 6.2% | commission 0.0% | wrong-content 2.5% | dependency/step 0.0% | overkill/step 6.2% | cross-day miss 42.9% | update miss 55.6% | precision_hit 86.8% | precision_any 90.6% | exact-set match rate 60.0% | exact-set avg reward 0.200 | set_precision 86.8% | set_recall 56.8% | set_f1 68.7%
Hit rates (by modality): event 61.4% | time 45.8%

## Run Timing

| Field | Value |
| --- | --- |
| Started (UTC) | 2026-08-06T09:15:11.058Z |
| Finished (UTC) | 2026-08-06T09:22:22.502Z |
| Duration | 7m 11.4s |

## Overall Counts

| Metric | Value |
| --- | --- |
| Hit | 46 |
| Late | 2 |
| Miss | 33 |
| False alarms | 5 |
| Commission | 0 |
| Wrong-content | 2 |
| Dependency violations | 0 |
| Overkill steps | 5 |
| State query calls | 10 |
| Check_time calls | 7 |
| Actions | 53 |
| Exact-set matches | 48 |
| Exact-set mismatches | 32 |
| Exact-set reward | 16 |
| Set TP | 46 |
| Set FP | 7 |
| Set FN | 35 |

## State Query Calls by Channel (Overall)

| Channel | Calls |
| --- | --- |
| bank_balance | 2 |
| clock | 7 |
| library_hold | 1 |

## Overall Rates

| Metric | Value |
| --- | --- |
| Hit rate | 56.8% |
| Late rate | 2.5% |
| Miss rate | 40.7% |
| False alarm/step | 6.2% |
| Commission rate | 0.0% |
| Wrong-content rate | 2.5% |
| Dependency/step | 0.0% |
| Overkill/step | 6.2% |
| Cross-day miss rate | 42.9% |
| Update miss rate | 55.6% |
| Precision hit | 86.8% |
| Precision any | 90.6% |
| Exact-set match rate | 60.0% |
| Exact-set avg reward | 0.200 |
| Set precision | 86.8% |
| Set recall | 56.8% |
| Set F1 | 68.7% |

## Modality Hit Rates

| Modality | Hit | Total | Hit rate |
| --- | --- | --- | --- |
| Event | 35 | 57 | 61.4% |
| Time (time + time_check) | 11 | 24 | 45.8% |

## Monitoring Categories

| Category | Hit | Late | Miss | Total | Hit rate | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| no_proactive_monitoring | 35 | 0 | 7 | 42 | 83.3% | 83.3% |
| proactive_monitoring_required | 11 | 2 | 26 | 39 | 28.2% | 33.3% |

Note: `proactive_monitoring_required` hit rate is no-late-credit by design.

## Proactive Required by Channel

| Channel | Hit | Late | Miss | Total | Hit rate (no late credit) | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| appointment_portal | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| bank_balance | 0 | 0 | 2 | 2 | 0.0% | 0.0% |
| calendar | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| clock | 11 | 1 | 12 | 24 | 45.8% | 50.0% |
| course_portal | 0 | 0 | 1 | 1 | 0.0% | 0.0% |
| email | 0 | 1 | 1 | 2 | 0.0% | 50.0% |
| library_hold | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| shipment_status | 0 | 0 | 1 | 1 | 0.0% | 0.0% |

## Per-Day Summary

| Day | Hit | Late | Miss | Hit rate | Late rate | Miss rate | False alarm/step | Overkill/step | Event hit rate | Time hit rate | No-proactive hit rate | Proactive hit rate (no late credit) | Exact-set match rate | Exact-set avg reward | Set precision | Set recall | Set F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monday | 6 | 0 | 6 | 50.0% | 0.0% | 50.0% | 15.4% | 7.7% | 44.4% | 66.7% | 66.7% | 33.3% | 61.5% | 0.231 | 75.0% | 50.0% | 60.0% |
| Tuesday | 7 | 0 | 4 | 63.6% | 0.0% | 36.4% | 0.0% | 0.0% | 57.1% | 75.0% | 100.0% | 42.9% | 69.2% | 0.385 | 100.0% | 63.6% | 77.8% |
| Wednesday | 5 | 0 | 6 | 45.5% | 0.0% | 54.5% | 0.0% | 0.0% | 44.4% | 50.0% | 66.7% | 20.0% | 60.0% | 0.200 | 100.0% | 45.5% | 62.5% |
| Thursday | 8 | 0 | 4 | 66.7% | 0.0% | 33.3% | 9.1% | 9.1% | 77.8% | 33.3% | 87.5% | 25.0% | 72.7% | 0.455 | 88.9% | 66.7% | 76.2% |
| Friday | 7 | 1 | 4 | 58.3% | 8.3% | 33.3% | 8.3% | 8.3% | 75.0% | 25.0% | 100.0% | 16.7% | 50.0% | 0.000 | 77.8% | 58.3% | 66.7% |
| Saturday | 8 | 0 | 6 | 57.1% | 0.0% | 42.9% | 0.0% | 0.0% | 70.0% | 25.0% | 87.5% | 16.7% | 60.0% | 0.200 | 100.0% | 57.1% | 72.7% |
| Sunday | 5 | 1 | 3 | 55.6% | 11.1% | 33.3% | 9.1% | 18.2% | 60.0% | 50.0% | 75.0% | 40.0% | 45.5% | -0.091 | 71.4% | 55.6% | 62.5% |

## State Query Calls by Channel (Per Day)

| Day | Channel | Calls |
| --- | --- | --- |
| Monday | clock | 1 |
| Tuesday | clock | 2 |
| Wednesday | bank_balance | 1 |
| Thursday | clock | 1 |
| Friday | clock | 2 |
| Friday | library_hold | 1 |
| Saturday | (none) | 0 |
| Sunday | bank_balance | 1 |
| Sunday | clock | 1 |
