# PM-Bench score report

## Summary

Hit: 52 | Late: 3 | Miss: 26 | False alarms: 4 | Commission: 0 | Wrong-content: 3 | Dependency violations: 0 | Overkill steps: 5 | state query calls: 9 | check_time calls: 7 | Actions: 59
Exact-set: matches 51 | mismatches 29 | reward 22
Set micro: TP 52 | FP 7 | FN 29
Cross-day: hit 7 | late 0 | miss 0 | total 7
Updates: hit 4 | late 1 | miss 4 | canceled 2 | total 11 | violations 3
Rates: hit 64.2% | late 3.7% | miss 32.1% | false alarm/step 5.0% | commission 0.0% | wrong-content 3.7% | dependency/step 0.0% | overkill/step 6.2% | cross-day miss 0.0% | update miss 44.4% | precision_hit 88.1% | precision_any 93.2% | exact-set match rate 63.7% | exact-set avg reward 0.275 | set_precision 88.1% | set_recall 64.2% | set_f1 74.3%
Hit rates (by modality): event 70.2% | time 50.0%

## Run Timing

| Field | Value |
| --- | --- |
| Started (UTC) | 2026-08-06T16:08:56.049Z |
| Finished (UTC) | 2026-08-06T16:16:17.008Z |
| Duration | 7m 21.0s |

## Overall Counts

| Metric | Value |
| --- | --- |
| Hit | 52 |
| Late | 3 |
| Miss | 26 |
| False alarms | 4 |
| Commission | 0 |
| Wrong-content | 3 |
| Dependency violations | 0 |
| Overkill steps | 5 |
| State query calls | 9 |
| Check_time calls | 7 |
| Actions | 59 |
| Exact-set matches | 51 |
| Exact-set mismatches | 29 |
| Exact-set reward | 22 |
| Set TP | 52 |
| Set FP | 7 |
| Set FN | 29 |

## State Query Calls by Channel (Overall)

| Channel | Calls |
| --- | --- |
| bank_balance | 2 |
| clock | 7 |

## Overall Rates

| Metric | Value |
| --- | --- |
| Hit rate | 64.2% |
| Late rate | 3.7% |
| Miss rate | 32.1% |
| False alarm/step | 5.0% |
| Commission rate | 0.0% |
| Wrong-content rate | 3.7% |
| Dependency/step | 0.0% |
| Overkill/step | 6.2% |
| Cross-day miss rate | 0.0% |
| Update miss rate | 44.4% |
| Precision hit | 88.1% |
| Precision any | 93.2% |
| Exact-set match rate | 63.7% |
| Exact-set avg reward | 0.275 |
| Set precision | 88.1% |
| Set recall | 64.2% |
| Set F1 | 74.3% |

## Modality Hit Rates

| Modality | Hit | Total | Hit rate |
| --- | --- | --- | --- |
| Event | 40 | 57 | 70.2% |
| Time (time + time_check) | 12 | 24 | 50.0% |

## Monitoring Categories

| Category | Hit | Late | Miss | Total | Hit rate | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| no_proactive_monitoring | 40 | 0 | 2 | 42 | 95.2% | 95.2% |
| proactive_monitoring_required | 12 | 3 | 24 | 39 | 30.8% | 38.5% |

Note: `proactive_monitoring_required` hit rate is no-late-credit by design.

## Proactive Required by Channel

| Channel | Hit | Late | Miss | Total | Hit rate (no late credit) | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| appointment_portal | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| bank_balance | 0 | 0 | 2 | 2 | 0.0% | 0.0% |
| calendar | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| clock | 12 | 2 | 10 | 24 | 50.0% | 58.3% |
| course_portal | 0 | 0 | 1 | 1 | 0.0% | 0.0% |
| email | 0 | 1 | 1 | 2 | 0.0% | 50.0% |
| library_hold | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| shipment_status | 0 | 0 | 1 | 1 | 0.0% | 0.0% |

## Per-Day Summary

| Day | Hit | Late | Miss | Hit rate | Late rate | Miss rate | False alarm/step | Overkill/step | Event hit rate | Time hit rate | No-proactive hit rate | Proactive hit rate (no late credit) | Exact-set match rate | Exact-set avg reward | Set precision | Set recall | Set F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monday | 6 | 0 | 6 | 50.0% | 0.0% | 50.0% | 15.4% | 7.7% | 44.4% | 66.7% | 66.7% | 33.3% | 61.5% | 0.231 | 75.0% | 50.0% | 60.0% |
| Tuesday | 7 | 0 | 4 | 63.6% | 0.0% | 36.4% | 0.0% | 0.0% | 57.1% | 75.0% | 100.0% | 42.9% | 69.2% | 0.385 | 100.0% | 63.6% | 77.8% |
| Wednesday | 7 | 0 | 4 | 63.6% | 0.0% | 36.4% | 0.0% | 0.0% | 66.7% | 50.0% | 100.0% | 20.0% | 70.0% | 0.400 | 100.0% | 63.6% | 77.8% |
| Thursday | 9 | 1 | 2 | 75.0% | 8.3% | 16.7% | 0.0% | 9.1% | 88.9% | 33.3% | 100.0% | 25.0% | 72.7% | 0.455 | 90.0% | 75.0% | 81.8% |
| Friday | 7 | 1 | 4 | 58.3% | 8.3% | 33.3% | 8.3% | 8.3% | 75.0% | 25.0% | 100.0% | 16.7% | 50.0% | 0.000 | 77.8% | 58.3% | 66.7% |
| Saturday | 9 | 0 | 5 | 64.3% | 0.0% | 35.7% | 0.0% | 0.0% | 80.0% | 25.0% | 100.0% | 16.7% | 60.0% | 0.200 | 100.0% | 64.3% | 78.3% |
| Sunday | 7 | 1 | 1 | 77.8% | 11.1% | 11.1% | 9.1% | 18.2% | 80.0% | 75.0% | 100.0% | 60.0% | 63.6% | 0.273 | 77.8% | 77.8% | 77.8% |

## State Query Calls by Channel (Per Day)

| Day | Channel | Calls |
| --- | --- | --- |
| Monday | clock | 1 |
| Tuesday | clock | 2 |
| Wednesday | bank_balance | 1 |
| Thursday | clock | 1 |
| Friday | clock | 2 |
| Saturday | (none) | 0 |
| Sunday | bank_balance | 1 |
| Sunday | clock | 1 |
