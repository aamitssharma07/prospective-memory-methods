# PM-Bench score report

## Summary

Hit: 55 | Late: 2 | Miss: 24 | False alarms: 4 | Commission: 0 | Wrong-content: 3 | Dependency violations: 0 | Overkill steps: 4 | state query calls: 6 | check_time calls: 6 | Actions: 61
Exact-set: matches 55 | mismatches 25 | reward 30
Set micro: TP 55 | FP 6 | FN 26
Cross-day: hit 6 | late 0 | miss 1 | total 7
Updates: hit 5 | late 0 | miss 4 | canceled 2 | total 11 | violations 0
Rates: hit 67.9% | late 2.5% | miss 29.6% | false alarm/step 5.0% | commission 0.0% | wrong-content 3.7% | dependency/step 0.0% | overkill/step 5.0% | cross-day miss 14.3% | update miss 44.4% | precision_hit 90.2% | precision_any 93.4% | exact-set match rate 68.8% | exact-set avg reward 0.375 | set_precision 90.2% | set_recall 67.9% | set_f1 77.5%
Hit rates (by modality): event 70.2% | time 62.5%

## Run Timing

| Field | Value |
| --- | --- |
| Started (UTC) | 2026-08-05T18:46:15.016Z |
| Finished (UTC) | 2026-08-05T18:51:46.871Z |
| Duration | 5m 31.9s |

## Overall Counts

| Metric | Value |
| --- | --- |
| Hit | 55 |
| Late | 2 |
| Miss | 24 |
| False alarms | 4 |
| Commission | 0 |
| Wrong-content | 3 |
| Dependency violations | 0 |
| Overkill steps | 4 |
| State query calls | 6 |
| Check_time calls | 6 |
| Actions | 61 |
| Exact-set matches | 55 |
| Exact-set mismatches | 25 |
| Exact-set reward | 30 |
| Set TP | 55 |
| Set FP | 6 |
| Set FN | 26 |

## State Query Calls by Channel (Overall)

| Channel | Calls |
| --- | --- |
| clock | 6 |

## Overall Rates

| Metric | Value |
| --- | --- |
| Hit rate | 67.9% |
| Late rate | 2.5% |
| Miss rate | 29.6% |
| False alarm/step | 5.0% |
| Commission rate | 0.0% |
| Wrong-content rate | 3.7% |
| Dependency/step | 0.0% |
| Overkill/step | 5.0% |
| Cross-day miss rate | 14.3% |
| Update miss rate | 44.4% |
| Precision hit | 90.2% |
| Precision any | 93.4% |
| Exact-set match rate | 68.8% |
| Exact-set avg reward | 0.375 |
| Set precision | 90.2% |
| Set recall | 67.9% |
| Set F1 | 77.5% |

## Modality Hit Rates

| Modality | Hit | Total | Hit rate |
| --- | --- | --- | --- |
| Event | 40 | 57 | 70.2% |
| Time (time + time_check) | 15 | 24 | 62.5% |

## Monitoring Categories

| Category | Hit | Late | Miss | Total | Hit rate | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| no_proactive_monitoring | 40 | 0 | 2 | 42 | 95.2% | 95.2% |
| proactive_monitoring_required | 15 | 2 | 22 | 39 | 38.5% | 43.6% |

Note: `proactive_monitoring_required` hit rate is no-late-credit by design.

## Proactive Required by Channel

| Channel | Hit | Late | Miss | Total | Hit rate (no late credit) | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| appointment_portal | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| bank_balance | 0 | 0 | 2 | 2 | 0.0% | 0.0% |
| calendar | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| clock | 15 | 1 | 8 | 24 | 62.5% | 66.7% |
| course_portal | 0 | 0 | 1 | 1 | 0.0% | 0.0% |
| email | 0 | 1 | 1 | 2 | 0.0% | 50.0% |
| library_hold | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| shipment_status | 0 | 0 | 1 | 1 | 0.0% | 0.0% |

## Per-Day Summary

| Day | Hit | Late | Miss | Hit rate | Late rate | Miss rate | False alarm/step | Overkill/step | Event hit rate | Time hit rate | No-proactive hit rate | Proactive hit rate (no late credit) | Exact-set match rate | Exact-set avg reward | Set precision | Set recall | Set F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monday | 8 | 0 | 4 | 66.7% | 0.0% | 33.3% | 0.0% | 0.0% | 66.7% | 66.7% | 100.0% | 33.3% | 76.9% | 0.538 | 100.0% | 66.7% | 80.0% |
| Tuesday | 8 | 0 | 3 | 72.7% | 0.0% | 27.3% | 0.0% | 0.0% | 57.1% | 100.0% | 100.0% | 57.1% | 76.9% | 0.538 | 100.0% | 72.7% | 84.2% |
| Wednesday | 7 | 0 | 4 | 63.6% | 0.0% | 36.4% | 0.0% | 0.0% | 66.7% | 50.0% | 100.0% | 20.0% | 70.0% | 0.400 | 100.0% | 63.6% | 77.8% |
| Thursday | 9 | 0 | 3 | 75.0% | 0.0% | 25.0% | 9.1% | 9.1% | 77.8% | 66.7% | 87.5% | 50.0% | 72.7% | 0.455 | 90.0% | 75.0% | 81.8% |
| Friday | 9 | 1 | 2 | 75.0% | 8.3% | 16.7% | 8.3% | 8.3% | 75.0% | 75.0% | 100.0% | 50.0% | 66.7% | 0.333 | 81.8% | 75.0% | 78.3% |
| Saturday | 8 | 0 | 6 | 57.1% | 0.0% | 42.9% | 10.0% | 0.0% | 70.0% | 25.0% | 87.5% | 16.7% | 60.0% | 0.200 | 88.9% | 57.1% | 69.6% |
| Sunday | 6 | 1 | 2 | 66.7% | 11.1% | 22.2% | 9.1% | 18.2% | 80.0% | 50.0% | 100.0% | 40.0% | 54.5% | 0.091 | 75.0% | 66.7% | 70.6% |

## State Query Calls by Channel (Per Day)

| Day | Channel | Calls |
| --- | --- | --- |
| Monday | clock | 1 |
| Tuesday | clock | 2 |
| Wednesday | (none) | 0 |
| Thursday | clock | 1 |
| Friday | clock | 1 |
| Saturday | (none) | 0 |
| Sunday | clock | 1 |
