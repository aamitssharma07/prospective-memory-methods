# PM-Bench score report

## Summary

Hit: 49 | Late: 2 | Miss: 30 | False alarms: 9 | Commission: 0 | Wrong-content: 3 | Dependency violations: 0 | Overkill steps: 8 | state query calls: 6 | check_time calls: 4 | Actions: 60
Exact-set: matches 48 | mismatches 32 | reward 16
Set micro: TP 49 | FP 11 | FN 32
Cross-day: hit 5 | late 0 | miss 2 | total 7
Updates: hit 2 | late 0 | miss 7 | canceled 2 | total 11 | violations 4
Rates: hit 60.5% | late 2.5% | miss 37.0% | false alarm/step 11.2% | commission 0.0% | wrong-content 3.7% | dependency/step 0.0% | overkill/step 10.0% | cross-day miss 28.6% | update miss 77.8% | precision_hit 81.7% | precision_any 85.0% | exact-set match rate 60.0% | exact-set avg reward 0.200 | set_precision 81.7% | set_recall 60.5% | set_f1 69.5%
Hit rates (by modality): event 66.7% | time 45.8%

## Run Timing

| Field | Value |
| --- | --- |
| Started (UTC) | 2026-08-06T09:23:19.123Z |
| Finished (UTC) | 2026-08-06T09:45:17.991Z |
| Duration | 21m 58.9s |

## Overall Counts

| Metric | Value |
| --- | --- |
| Hit | 49 |
| Late | 2 |
| Miss | 30 |
| False alarms | 9 |
| Commission | 0 |
| Wrong-content | 3 |
| Dependency violations | 0 |
| Overkill steps | 8 |
| State query calls | 6 |
| Check_time calls | 4 |
| Actions | 60 |
| Exact-set matches | 48 |
| Exact-set mismatches | 32 |
| Exact-set reward | 16 |
| Set TP | 49 |
| Set FP | 11 |
| Set FN | 32 |

## State Query Calls by Channel (Overall)

| Channel | Calls |
| --- | --- |
| bank_balance | 2 |
| clock | 4 |

## Overall Rates

| Metric | Value |
| --- | --- |
| Hit rate | 60.5% |
| Late rate | 2.5% |
| Miss rate | 37.0% |
| False alarm/step | 11.2% |
| Commission rate | 0.0% |
| Wrong-content rate | 3.7% |
| Dependency/step | 0.0% |
| Overkill/step | 10.0% |
| Cross-day miss rate | 28.6% |
| Update miss rate | 77.8% |
| Precision hit | 81.7% |
| Precision any | 85.0% |
| Exact-set match rate | 60.0% |
| Exact-set avg reward | 0.200 |
| Set precision | 81.7% |
| Set recall | 60.5% |
| Set F1 | 69.5% |

## Modality Hit Rates

| Modality | Hit | Total | Hit rate |
| --- | --- | --- | --- |
| Event | 38 | 57 | 66.7% |
| Time (time + time_check) | 11 | 24 | 45.8% |

## Monitoring Categories

| Category | Hit | Late | Miss | Total | Hit rate | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| no_proactive_monitoring | 38 | 0 | 4 | 42 | 90.5% | 90.5% |
| proactive_monitoring_required | 11 | 2 | 26 | 39 | 28.2% | 33.3% |

Note: `proactive_monitoring_required` hit rate is no-late-credit by design.

## Proactive Required by Channel

| Channel | Hit | Late | Miss | Total | Hit rate (no late credit) | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| appointment_portal | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| bank_balance | 0 | 0 | 2 | 2 | 0.0% | 0.0% |
| calendar | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| clock | 11 | 1 | 12 | 24 | 45.8% | 50.0% |
| course_portal | 0 | 0 | 1 | 1 | 0.0% | 0.0% |
| email | 0 | 1 | 1 | 2 | 0.0% | 50.0% |
| library_hold | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| shipment_status | 0 | 0 | 1 | 1 | 0.0% | 0.0% |

## Per-Day Summary

| Day | Hit | Late | Miss | Hit rate | Late rate | Miss rate | False alarm/step | Overkill/step | Event hit rate | Time hit rate | No-proactive hit rate | Proactive hit rate (no late credit) | Exact-set match rate | Exact-set avg reward | Set precision | Set recall | Set F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monday | 7 | 0 | 5 | 58.3% | 0.0% | 41.7% | 23.1% | 15.4% | 55.6% | 66.7% | 83.3% | 33.3% | 61.5% | 0.231 | 70.0% | 58.3% | 63.6% |
| Tuesday | 6 | 0 | 5 | 54.5% | 0.0% | 45.5% | 0.0% | 0.0% | 57.1% | 50.0% | 100.0% | 28.6% | 69.2% | 0.385 | 100.0% | 54.5% | 70.6% |
| Wednesday | 5 | 0 | 6 | 45.5% | 0.0% | 54.5% | 0.0% | 0.0% | 44.4% | 50.0% | 66.7% | 20.0% | 60.0% | 0.200 | 100.0% | 45.5% | 62.5% |
| Thursday | 9 | 0 | 3 | 75.0% | 0.0% | 25.0% | 18.2% | 18.2% | 88.9% | 33.3% | 100.0% | 25.0% | 63.6% | 0.273 | 81.8% | 75.0% | 78.3% |
| Friday | 8 | 1 | 3 | 66.7% | 8.3% | 25.0% | 16.7% | 16.7% | 62.5% | 75.0% | 83.3% | 50.0% | 58.3% | 0.167 | 72.7% | 66.7% | 69.6% |
| Saturday | 9 | 0 | 5 | 64.3% | 0.0% | 35.7% | 0.0% | 0.0% | 80.0% | 25.0% | 100.0% | 16.7% | 60.0% | 0.200 | 100.0% | 64.3% | 78.3% |
| Sunday | 5 | 1 | 3 | 55.6% | 11.1% | 33.3% | 18.2% | 18.2% | 80.0% | 25.0% | 100.0% | 20.0% | 45.5% | -0.091 | 62.5% | 55.6% | 58.8% |

## State Query Calls by Channel (Per Day)

| Day | Channel | Calls |
| --- | --- | --- |
| Monday | clock | 1 |
| Tuesday | clock | 1 |
| Wednesday | bank_balance | 1 |
| Thursday | (none) | 0 |
| Friday | clock | 1 |
| Saturday | (none) | 0 |
| Sunday | bank_balance | 1 |
| Sunday | clock | 1 |
