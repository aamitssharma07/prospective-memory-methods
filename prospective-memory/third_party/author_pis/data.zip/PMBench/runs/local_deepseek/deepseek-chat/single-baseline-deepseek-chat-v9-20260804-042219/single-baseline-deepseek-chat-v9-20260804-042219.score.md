# PM-Bench score report

## Summary

Hit: 45 | Late: 2 | Miss: 34 | False alarms: 6 | Commission: 0 | Wrong-content: 4 | Dependency violations: 0 | Overkill steps: 5 | state query calls: 9 | check_time calls: 7 | Actions: 53
Exact-set: matches 49 | mismatches 31 | reward 18
Set micro: TP 45 | FP 8 | FN 36
Cross-day: hit 4 | late 0 | miss 3 | total 7
Updates: hit 3 | late 0 | miss 6 | canceled 2 | total 11 | violations 3
Rates: hit 55.6% | late 2.5% | miss 42.0% | false alarm/step 7.5% | commission 0.0% | wrong-content 4.9% | dependency/step 0.0% | overkill/step 6.2% | cross-day miss 42.9% | update miss 66.7% | precision_hit 84.9% | precision_any 88.7% | exact-set match rate 61.3% | exact-set avg reward 0.225 | set_precision 84.9% | set_recall 55.6% | set_f1 67.2%
Hit rates (by modality): event 63.2% | time 37.5%

## Run Timing

| Field | Value |
| --- | --- |
| Started (UTC) | 2026-08-03T20:22:19.595Z |
| Finished (UTC) | 2026-08-03T20:23:39.359Z |
| Duration | 1m 19.8s |

## Overall Counts

| Metric | Value |
| --- | --- |
| Hit | 45 |
| Late | 2 |
| Miss | 34 |
| False alarms | 6 |
| Commission | 0 |
| Wrong-content | 4 |
| Dependency violations | 0 |
| Overkill steps | 5 |
| State query calls | 9 |
| Check_time calls | 7 |
| Actions | 53 |
| Exact-set matches | 49 |
| Exact-set mismatches | 31 |
| Exact-set reward | 18 |
| Set TP | 45 |
| Set FP | 8 |
| Set FN | 36 |

## State Query Calls by Channel (Overall)

| Channel | Calls |
| --- | --- |
| bank_balance | 2 |
| clock | 7 |

## Overall Rates

| Metric | Value |
| --- | --- |
| Hit rate | 55.6% |
| Late rate | 2.5% |
| Miss rate | 42.0% |
| False alarm/step | 7.5% |
| Commission rate | 0.0% |
| Wrong-content rate | 4.9% |
| Dependency/step | 0.0% |
| Overkill/step | 6.2% |
| Cross-day miss rate | 42.9% |
| Update miss rate | 66.7% |
| Precision hit | 84.9% |
| Precision any | 88.7% |
| Exact-set match rate | 61.3% |
| Exact-set avg reward | 0.225 |
| Set precision | 84.9% |
| Set recall | 55.6% |
| Set F1 | 67.2% |

## Modality Hit Rates

| Modality | Hit | Total | Hit rate |
| --- | --- | --- | --- |
| Event | 36 | 57 | 63.2% |
| Time (time + time_check) | 9 | 24 | 37.5% |

## Monitoring Categories

| Category | Hit | Late | Miss | Total | Hit rate | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| no_proactive_monitoring | 36 | 0 | 6 | 42 | 85.7% | 85.7% |
| proactive_monitoring_required | 9 | 2 | 28 | 39 | 23.1% | 28.2% |

Note: `proactive_monitoring_required` hit rate is no-late-credit by design.

## Proactive Required by Channel

| Channel | Hit | Late | Miss | Total | Hit rate (no late credit) | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| appointment_portal | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| bank_balance | 0 | 0 | 2 | 2 | 0.0% | 0.0% |
| calendar | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| clock | 9 | 1 | 14 | 24 | 37.5% | 41.7% |
| course_portal | 0 | 0 | 1 | 1 | 0.0% | 0.0% |
| email | 0 | 1 | 1 | 2 | 0.0% | 50.0% |
| library_hold | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| shipment_status | 0 | 0 | 1 | 1 | 0.0% | 0.0% |

## Per-Day Summary

| Day | Hit | Late | Miss | Hit rate | Late rate | Miss rate | False alarm/step | Overkill/step | Event hit rate | Time hit rate | No-proactive hit rate | Proactive hit rate (no late credit) | Exact-set match rate | Exact-set avg reward | Set precision | Set recall | Set F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monday | 7 | 0 | 5 | 58.3% | 0.0% | 41.7% | 7.7% | 7.7% | 55.6% | 66.7% | 83.3% | 33.3% | 69.2% | 0.385 | 87.5% | 58.3% | 70.0% |
| Tuesday | 7 | 0 | 4 | 63.6% | 0.0% | 36.4% | 0.0% | 0.0% | 57.1% | 75.0% | 100.0% | 42.9% | 69.2% | 0.385 | 100.0% | 63.6% | 77.8% |
| Wednesday | 5 | 0 | 6 | 45.5% | 0.0% | 54.5% | 0.0% | 0.0% | 44.4% | 50.0% | 66.7% | 20.0% | 60.0% | 0.200 | 100.0% | 45.5% | 62.5% |
| Thursday | 8 | 0 | 4 | 66.7% | 0.0% | 33.3% | 0.0% | 0.0% | 77.8% | 33.3% | 87.5% | 25.0% | 81.8% | 0.636 | 100.0% | 66.7% | 80.0% |
| Friday | 6 | 1 | 5 | 50.0% | 8.3% | 41.7% | 8.3% | 8.3% | 62.5% | 25.0% | 83.3% | 16.7% | 50.0% | 0.000 | 75.0% | 50.0% | 60.0% |
| Saturday | 9 | 0 | 5 | 64.3% | 0.0% | 35.7% | 10.0% | 0.0% | 80.0% | 25.0% | 100.0% | 16.7% | 60.0% | 0.200 | 90.0% | 64.3% | 75.0% |
| Sunday | 3 | 1 | 5 | 33.3% | 11.1% | 55.6% | 27.3% | 27.3% | 60.0% | 0.0% | 75.0% | 0.0% | 36.4% | -0.273 | 42.9% | 33.3% | 37.5% |

## State Query Calls by Channel (Per Day)

| Day | Channel | Calls |
| --- | --- | --- |
| Monday | clock | 1 |
| Tuesday | clock | 2 |
| Wednesday | bank_balance | 1 |
| Thursday | clock | 1 |
| Friday | clock | 2 |
| Saturday | (none) | 0 |
| Sunday | bank_balance | 1 |
| Sunday | clock | 1 |
