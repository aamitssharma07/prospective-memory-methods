# PM-Bench score report

## Summary

Hit: 46 | Late: 2 | Miss: 33 | False alarms: 9 | Commission: 0 | Wrong-content: 4 | Dependency violations: 0 | Overkill steps: 7 | state query calls: 7 | check_time calls: 5 | Actions: 57
Exact-set: matches 47 | mismatches 33 | reward 14
Set micro: TP 46 | FP 11 | FN 35
Cross-day: hit 4 | late 0 | miss 3 | total 7
Updates: hit 1 | late 0 | miss 8 | canceled 2 | total 11 | violations 5
Rates: hit 56.8% | late 2.5% | miss 40.7% | false alarm/step 11.2% | commission 0.0% | wrong-content 4.9% | dependency/step 0.0% | overkill/step 8.8% | cross-day miss 42.9% | update miss 88.9% | precision_hit 80.7% | precision_any 84.2% | exact-set match rate 58.8% | exact-set avg reward 0.175 | set_precision 80.7% | set_recall 56.8% | set_f1 66.7%
Hit rates (by modality): event 63.2% | time 41.7%

## Run Timing

| Field | Value |
| --- | --- |
| Started (UTC) | 2026-08-05T18:52:16.253Z |
| Finished (UTC) | 2026-08-05T19:16:05.878Z |
| Duration | 23m 49.6s |

## Overall Counts

| Metric | Value |
| --- | --- |
| Hit | 46 |
| Late | 2 |
| Miss | 33 |
| False alarms | 9 |
| Commission | 0 |
| Wrong-content | 4 |
| Dependency violations | 0 |
| Overkill steps | 7 |
| State query calls | 7 |
| Check_time calls | 5 |
| Actions | 57 |
| Exact-set matches | 47 |
| Exact-set mismatches | 33 |
| Exact-set reward | 14 |
| Set TP | 46 |
| Set FP | 11 |
| Set FN | 35 |

## State Query Calls by Channel (Overall)

| Channel | Calls |
| --- | --- |
| bank_balance | 2 |
| clock | 5 |

## Overall Rates

| Metric | Value |
| --- | --- |
| Hit rate | 56.8% |
| Late rate | 2.5% |
| Miss rate | 40.7% |
| False alarm/step | 11.2% |
| Commission rate | 0.0% |
| Wrong-content rate | 4.9% |
| Dependency/step | 0.0% |
| Overkill/step | 8.8% |
| Cross-day miss rate | 42.9% |
| Update miss rate | 88.9% |
| Precision hit | 80.7% |
| Precision any | 84.2% |
| Exact-set match rate | 58.8% |
| Exact-set avg reward | 0.175 |
| Set precision | 80.7% |
| Set recall | 56.8% |
| Set F1 | 66.7% |

## Modality Hit Rates

| Modality | Hit | Total | Hit rate |
| --- | --- | --- | --- |
| Event | 36 | 57 | 63.2% |
| Time (time + time_check) | 10 | 24 | 41.7% |

## Monitoring Categories

| Category | Hit | Late | Miss | Total | Hit rate | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| no_proactive_monitoring | 36 | 0 | 6 | 42 | 85.7% | 85.7% |
| proactive_monitoring_required | 10 | 2 | 27 | 39 | 25.6% | 30.8% |

Note: `proactive_monitoring_required` hit rate is no-late-credit by design.

## Proactive Required by Channel

| Channel | Hit | Late | Miss | Total | Hit rate (no late credit) | Any rate (hit+late) |
| --- | --- | --- | --- | --- | --- | --- |
| appointment_portal | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| bank_balance | 0 | 0 | 2 | 2 | 0.0% | 0.0% |
| calendar | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| clock | 10 | 1 | 13 | 24 | 41.7% | 45.8% |
| course_portal | 0 | 0 | 1 | 1 | 0.0% | 0.0% |
| email | 0 | 1 | 1 | 2 | 0.0% | 50.0% |
| library_hold | 0 | 0 | 3 | 3 | 0.0% | 0.0% |
| shipment_status | 0 | 0 | 1 | 1 | 0.0% | 0.0% |

## Per-Day Summary

| Day | Hit | Late | Miss | Hit rate | Late rate | Miss rate | False alarm/step | Overkill/step | Event hit rate | Time hit rate | No-proactive hit rate | Proactive hit rate (no late credit) | Exact-set match rate | Exact-set avg reward | Set precision | Set recall | Set F1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Monday | 6 | 0 | 6 | 50.0% | 0.0% | 50.0% | 30.8% | 15.4% | 44.4% | 66.7% | 66.7% | 33.3% | 53.8% | 0.077 | 60.0% | 50.0% | 54.5% |
| Tuesday | 6 | 0 | 5 | 54.5% | 0.0% | 45.5% | 0.0% | 0.0% | 57.1% | 50.0% | 100.0% | 28.6% | 69.2% | 0.385 | 100.0% | 54.5% | 70.6% |
| Wednesday | 5 | 0 | 6 | 45.5% | 0.0% | 54.5% | 0.0% | 0.0% | 44.4% | 50.0% | 66.7% | 20.0% | 60.0% | 0.200 | 100.0% | 45.5% | 62.5% |
| Thursday | 9 | 0 | 3 | 75.0% | 0.0% | 25.0% | 18.2% | 18.2% | 88.9% | 33.3% | 100.0% | 25.0% | 63.6% | 0.273 | 81.8% | 75.0% | 78.3% |
| Friday | 7 | 1 | 4 | 58.3% | 8.3% | 33.3% | 8.3% | 8.3% | 62.5% | 50.0% | 83.3% | 33.3% | 58.3% | 0.167 | 77.8% | 58.3% | 66.7% |
| Saturday | 8 | 0 | 6 | 57.1% | 0.0% | 42.9% | 0.0% | 0.0% | 70.0% | 25.0% | 87.5% | 16.7% | 60.0% | 0.200 | 100.0% | 57.1% | 72.7% |
| Sunday | 5 | 1 | 3 | 55.6% | 11.1% | 33.3% | 18.2% | 18.2% | 80.0% | 25.0% | 100.0% | 20.0% | 45.5% | -0.091 | 62.5% | 55.6% | 58.8% |

## State Query Calls by Channel (Per Day)

| Day | Channel | Calls |
| --- | --- | --- |
| Monday | clock | 1 |
| Tuesday | clock | 1 |
| Wednesday | bank_balance | 1 |
| Thursday | clock | 1 |
| Friday | clock | 1 |
| Saturday | (none) | 0 |
| Sunday | bank_balance | 1 |
| Sunday | clock | 1 |
